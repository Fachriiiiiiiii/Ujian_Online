<?php
session_start();
include "../config/koneksi.php";
if ($_SESSION['role'] != "admin") {
    header("Location: ../auth/login.php");
    exit();
}
$id = $_GET['id'];
$q = mysqli_query($conn, "SELECT * FROM soal WHERE id='$id'");
$d = mysqli_fetch_assoc($q);

if (isset($_POST['update'])) {
    $pertanyaan = $_POST['pertanyaan'];
    $a = $_POST['opsi_a'];
    $b = $_POST['opsi_b'];
    $c = $_POST['opsi_c'];
    $d_ = $_POST['opsi_d'];
    $jawaban = $_POST['jawaban'];
    $update = mysqli_query($conn, "UPDATE soal SET pertanyaan='$pertanyaan', opsi_a='$a', opsi_b='$b', opsi_c='$c', opsi_d='$d_', jawaban='$jawaban' WHERE id='$id'");
    if ($update) {
        header("Location: kelola.php");
        exit();
    } else {
        echo "<p class='alert-error'>Gagal mengupdate soal.</p>";
    }
}
?>
<link rel="stylesheet" type="text/css" href="../assets/style.css">
<div class="container" style="max-width:600px;">
<h2>Edit Soal</h2>
<form method="post">
    <div style="margin-bottom:16px;">
        <label>Pertanyaan</label>
        <textarea name="pertanyaan" required style="width:100%;height:70px;"><?= htmlspecialchars($d['pertanyaan']) ?></textarea>
    </div>
    <div style="margin-bottom:16px;">
        <label>Opsi A</label>
        <input type="text" name="opsi_a" value="<?= htmlspecialchars($d['opsi_a']) ?>" required>
    </div>
    <div style="margin-bottom:16px;">
        <label>Opsi B</label>
        <input type="text" name="opsi_b" value="<?= htmlspecialchars($d['opsi_b']) ?>" required>
    </div>
    <div style="margin-bottom:16px;">
        <label>Opsi C</label>
        <input type="text" name="opsi_c" value="<?= htmlspecialchars($d['opsi_c']) ?>" required>
    </div>
    <div style="margin-bottom:16px;">
        <label>Opsi D</label>
        <input type="text" name="opsi_d" value="<?= htmlspecialchars($d['opsi_d']) ?>" required>
    </div>
    <div style="margin-bottom:24px;">
        <label>Kunci Jawaban</label>
        <select name="jawaban" required>
            <option value="">Pilih Kunci</option>
            <option value="A" <?= $d['jawaban']=='A'?'selected':'' ?>>A</option>
            <option value="B" <?= $d['jawaban']=='B'?'selected':'' ?>>B</option>
            <option value="C" <?= $d['jawaban']=='C'?'selected':'' ?>>C</option>
            <option value="D" <?= $d['jawaban']=='D'?'selected':'' ?>>D</option>
        </select>
    </div>
    <button type="submit" name="update">Update</button>
    <a href="kelola.php" style="margin-left:10px;">
        <button type="button">Kembali</button>
    </a>
</form>
</div>
