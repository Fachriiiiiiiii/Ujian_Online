<?php
session_start();
if ($_SESSION['role'] != "admin") {
    header("Location: ../auth/login.php");
    exit();
}
?>
<link rel="stylesheet" type="text/css" href="../assets/style.css">
<div class="container" style="max-width:600px;">
    <h2>Dashboard Admin</h2>
    <div style="display:flex; flex-direction:column; gap:18px; margin-top:32px;">
        <a href="kelola.php" style="text-decoration:none;">
            <button type="button" style="width:100%; font-size:17px;">Kelola Soal</button>
        </a>
        <a href="daftar_user.php" style="text-decoration:none;">
            <button type="button" style="width:100%; font-size:17px;">Daftar Siswa</button>
        </a>
        <a href="../auth/logout.php" style="text-decoration:none;">
            <button type="button" style="width:100%; font-size:17px; background:#d32f2f; color:#fff;">Logout</button>
        </a>
    </div>
</div>
