<?php
session_start();
include "../config/koneksi.php";
if ($_SESSION['role'] != "admin") {
    header("Location: ../auth/login.php");
    exit();
}
?>
<link rel="stylesheet" type="text/css" href="../assets/style.css">
<div class="container" style="max-width:1100px;">
<h2>Kelola Soal</h2>
<form method="get" style="margin-bottom:18px;">
    <label for="ujian" style="font-weight:600; color:#008080;">Pilih Ujian:</label>
    <select name="ujian" id="ujian" onchange="this.form.submit()" style="padding:7px 12px; border-radius:5px; border:1.5px solid #b2f7ef; background:#e3f6fc;">
        <option value="">-- Semua Ujian --</option>
        <?php
        $ujian_q = mysqli_query($conn, "SELECT * FROM ujian");
        $selected_ujian = isset($_GET['ujian']) ? $_GET['ujian'] : '';
        while ($u = mysqli_fetch_assoc($ujian_q)) {
            $sel = $selected_ujian == $u['id'] ? 'selected' : '';
            echo "<option value='$u[id]' $sel>$u[nama_ujian]</option>";
        }
        ?>
    </select>
    <noscript><button type="submit" style="margin-left:10px;">Tampilkan</button></noscript>
</form>
<a href="tambah.php<?php echo isset($_GET['ujian']) ? '?ujian='.$_GET['ujian'] : ''; ?>">
    <button type="button" style="margin-bottom:18px;">Tambah Soal</button>
</a>
<table border="1" style="width:100%; border-collapse:collapse; background:#fafdff; box-shadow:0 2px 8px rgba(0,0,0,0.07);">
<tr style="background:#b2f7ef; color:#008080;">
    <th>No</th>
    <th>Pertanyaan</th>
    <th>A</th>
    <th>B</th>
    <th>C</th>
    <th>D</th>
    <th>Kunci</th>
    <th>Aksi</th>
</tr>
<?php
$no = 1;
$where = "";
if (!empty($selected_ujian)) {
    $where = "WHERE id_ujian='$selected_ujian'";
}
$q = mysqli_query($conn, "SELECT * FROM soal $where");
while ($d = mysqli_fetch_array($q)) {
    echo "<tr style='background:" . ($no % 2 == 0 ? "#e3f6fc" : "#fff") . ";'>
        <td>$no</td>
        <td>".htmlspecialchars($d['pertanyaan'])."</td>
        <td>".htmlspecialchars($d['opsi_a'])."</td>
        <td>".htmlspecialchars($d['opsi_b'])."</td>
        <td>".htmlspecialchars($d['opsi_c'])."</td>
        <td>".htmlspecialchars($d['opsi_d'])."</td>
        <td>".htmlspecialchars($d['jawaban'])."</td>
        <td>
            <a href='edit.php?id=$d[id]'><button type='button'>Edit</button></a>
            <a href='hapus.php?id=$d[id]' onclick=\"return confirm('Yakin hapus soal ini?')\"><button type='button' style='background:#d32f2f;'>Hapus</button></a>
        </td>
    </tr>";
    $no++;
}
?>
</table>
<a href="dashboard.php" style="display:inline-block; margin-top:18px;">
    <button type="button">Kembali ke Dashboard</button>
</a>
</div>
