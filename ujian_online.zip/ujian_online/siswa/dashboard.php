<?php
session_start();
if ($_SESSION['role'] != "siswa") {
    header("Location: ../auth/login.php");
    exit();
}
?>
<link rel="stylesheet" type="text/css" href="../assets/style.css">
<div class="container" style="max-width:600px;">
    <h2>Dashboard Siswa</h2>
    <p>Selamat datang, <?php echo $_SESSION['username']; ?>!</p>
    <div style="display:flex; flex-direction:column; gap:18px; margin-top:32px;">
        <a href="panduan.php" style="text-decoration:none;">
            <button type="button" style="width:100%; font-size:17px;">Panduan Ujian</button>
        </a>
        <a href="mulai_ujian.php" style="text-decoration:none;">
            <button type="button" style="width:100%; font-size:17px;">Mulai Ujian</button>
        </a>
        <a href="hasil_ujian.php" style="text-decoration:none;">
            <button type="button" style="width:100%; font-size:17px;">Hasil Ujian</button>
        </a>
        <a href="../auth/logout.php" style="text-decoration:none;">
            <button type="button" style="width:100%; font-size:17px; background:#d32f2f; color:#fff;">Logout</button>
        </a>
    </div>
</div>
