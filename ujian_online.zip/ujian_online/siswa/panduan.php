<?php
session_start();
if ($_SESSION['role'] != "siswa") {
    header("Location: ../auth/login.php");
    exit();
}
?>
<link rel="stylesheet" type="text/css" href="../assets/style.css">
<div class="container" style="max-width:600px;">
<h2>Panduan Ujian</h2>
<ul>
    <li>Baca setiap soal dengan teliti.</li>
    <li>Jawab semua soal sebelum waktu habis.</li>
    <li>Setelah selesai, klik "Selesai Ujian" untuk melihat nilai.</li>
    <li>Pastikan koneksi internet stabil selama ujian.</li>
    <li>Jangan menutup browser sebelum ujian selesai.</li>
    <li>Gunakan tombol navigasi yang tersedia untuk berpindah soal.</li>
    <li>Jika ada kendala, segera hubungi pengawas ujian.</li>
</ul>
<a href="dashboard.php">
    <button type="button">Kembali</button>
</a>
</div>
