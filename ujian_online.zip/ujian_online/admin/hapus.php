<?php
session_start();
include "../config/koneksi.php";
if ($_SESSION['role'] != "admin") {
    header("Location: ../auth/login.php");
    exit();
}
$id = $_GET['id'];
// Hapus jawaban siswa yang terkait soal ini
mysqli_query($conn, "DELETE FROM jawaban_siswa WHERE id_soal='$id'");
// Baru hapus soal
mysqli_query($conn, "DELETE FROM soal WHERE id='$id'");
header("Location: kelola.php");
exit();
