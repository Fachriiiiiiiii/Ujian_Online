<?php
session_start();
include "../config/koneksi.php";
if ($_SESSION['role'] != "admin") {
    header("Location: ../auth/login.php");
    exit();
}

$selected_ujian = isset($_GET['ujian']) ? $_GET['ujian'] : '';
if (isset($_POST['simpan'])) {
    $id_ujian = $_POST['id_ujian'];
    $pertanyaan = $_POST['pertanyaan'];
    $a = $_POST['opsi_a'];
    $b = $_POST['opsi_b'];
    $c = $_POST['opsi_c'];
    $d = $_POST['opsi_d'];
    $jawaban = $_POST['jawaban'];
    $insert = mysqli_query($conn, "INSERT INTO soal (id_ujian, pertanyaan, opsi_a, opsi_b, opsi_c, opsi_d, jawaban) VALUES ('$id_ujian', '$pertanyaan', '$a', '$b', '$c', '$d', '$jawaban')");
    if ($insert) {
        header("Location: kelola.php");
        exit();
    } else {
        echo "<p class='alert-error'>Gagal menambah soal.</p>";
    }
}

?>
<link rel="stylesheet" type="text/css" href="../assets/style.css">
<div class="container" style="max-width:600px;">
<h2>Tambah Soal</h2>
<form method="post">
    <div style="margin-bottom:16px;">
        <label for="id_ujian">Ujian</label>
        <select name="id_ujian" id="id_ujian" required>
            <option value="">Pilih Ujian</option>
            <?php
            // Tambahkan pilihan default untuk RPL, Bahasa Inggris, MTK jika belum ada di database
            $default_ujian = [
                ['id' => 'rpl', 'nama_ujian' => 'RPL'],
                ['id' => 'b_inggris', 'nama_ujian' => 'Bahasa Inggris'],
                ['id' => 'mtk', 'nama_ujian' => 'Matematika']
            ];
            $ujian_q = mysqli_query($conn, "SELECT * FROM ujian");
            $ujian_ids = [];
            while ($u = mysqli_fetch_assoc($ujian_q)) {
                $ujian_ids[] = $u['nama_ujian'];
                $sel = ($selected_ujian == $u['id']) ? 'selected' : '';
                echo "<option value='$u[id]' $sel>$u[nama_ujian]</option>";
            }
            // Jika default ujian belum ada di database, tampilkan sebagai pilihan (non-db)
            foreach ($default_ujian as $du) {
                if (!in_array($du['nama_ujian'], $ujian_ids)) {
                    echo "<option value=''>$du[nama_ujian] (belum dibuat di database)</option>";
                }
            }
            ?>
        </select>
    </div>
    <div style="margin-bottom:16px;">
        <label>Pertanyaan</label>
        <textarea name="pertanyaan" required style="width:100%;height:70px;"></textarea>
    </div>
    <div style="margin-bottom:16px;">
        <label>Opsi A</label>
        <input type="text" name="opsi_a" required>
    </div>
    <div style="margin-bottom:16px;">
        <label>Opsi B</label>
        <input type="text" name="opsi_b" required>
    </div>
    <div style="margin-bottom:16px;">
        <label>Opsi C</label>
        <input type="text" name="opsi_c" required>
    </div>
    <div style="margin-bottom:16px;">
        <label>Opsi D</label>
        <input type="text" name="opsi_d" required>
    </div>
    <div style="margin-bottom:24px;">
        <label>Kunci Jawaban</label>
        <select name="jawaban" required>
            <option value="">Pilih Kunci</option>
            <option value="A">A</option>
            <option value="B">B</option>
            <option value="C">C</option>
            <option value="D">D</option>
        </select>
    </div>
    <button type="submit" name="simpan">Simpan</button>
    <a href="kelola.php" style="margin-left:10px;">
        <button type="button">Kembali</button>
    </a>
</form>
</div>
