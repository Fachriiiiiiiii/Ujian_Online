<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "ujian_online2"; // ganti dengan nama database yang sudah ada

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
