<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
include "../config/koneksi.php";

if (!isset($conn) || !$conn) {
    die("Koneksi database gagal.");
}

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Cek admin
    $admin = mysqli_query($conn, "SELECT * FROM users WHERE username='$username' AND password='$password' AND role='admin'");
    if (mysqli_num_rows($admin) > 0) {
        $_SESSION['username'] = $username;
        $_SESSION['role'] = "admin";
        header("Location: ../admin/dashboard.php");
        exit();
    }

    // Cek siswa
    $siswa = mysqli_query($conn, "SELECT * FROM users WHERE username='$username' AND password='$password' AND role='siswa'");
    if (mysqli_num_rows($siswa) > 0) {
        $_SESSION['username'] = $username;
        $_SESSION['role'] = "siswa";
        header("Location: ../siswa/dashboard.php");
        exit();
    }

    $error = "Login gagal, periksa username dan password!";
}
?>
<link rel="stylesheet" type="text/css" href="../assets/style.css">
<div class="container">
<h2>Login</h2>
<?php
if (isset($_GET['register']) && $_GET['register'] == 'success') {
    echo "<p style='color:green;'>Registrasi berhasil! Silakan login.</p>";
}
if (isset($error)) echo "<p style='color:red;'>$error</p>";
?>
<form method="post" style="display:inline;">
    Username: <input type="text" name="username" required><br><br>
    Password: <input type="password" name="password" required><br><br>
    <button type="submit" name="login">Login</button>
</form>
<a href="register.php" style="margin-left:10px;">
    <button type="button">Daftar Akun</button>
</a>
</div>
