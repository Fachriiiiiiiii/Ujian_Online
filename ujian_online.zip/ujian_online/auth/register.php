<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
include "../config/koneksi.php";

if (isset($_POST['register'])) {
    $nama = $_POST['nama'];
    $nis = $_POST['nis'];
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Cek apakah username sudah ada
    $cek = mysqli_query($conn, "SELECT * FROM users WHERE username='$username'");
    if (mysqli_num_rows($cek) > 0) {
        echo "Username sudah digunakan. Silakan pilih username lain.";
    } else {
        $insert = mysqli_query($conn, "INSERT INTO users (nama, nis, username, password, role) VALUES ('$nama', '$nis', '$username', '$password', 'siswa')");
        if ($insert) {
            // Redirect ke login setelah registrasi berhasil
            header("Location: login.php?register=success");
            exit();
        } else {
            echo "Gagal registrasi.";
        }
    }
}
?>
<link rel="stylesheet" type="text/css" href="../assets/style.css">
<div class="container">
    <h2>Registrasi Siswa</h2>
    <p style="text-align:center; color:#008080; margin-bottom:24px;">
        Silakan isi data diri Anda untuk membuat akun ujian.
    </p>
    <form method="post">
        <div style="margin-bottom:16px;">
            <label for="nama">Nama Lengkap</label>
            <input type="text" id="nama" name="nama" required>
        </div>
        <div style="margin-bottom:16px;">
            <label for="nis">NIS</label>
            <input type="text" id="nis" name="nis" required>
        </div>
        <div style="margin-bottom:16px;">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" required>
        </div>
        <div style="margin-bottom:24px;">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>
        </div>
        <button type="submit" name="register">Daftar</button>
        <a href="login.php" style="margin-left:10px;">
            <button type="button">Kembali ke Login</button>
        </a>
    </form>
</div>
