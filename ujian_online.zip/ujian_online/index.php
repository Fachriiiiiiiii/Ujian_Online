<!DOCTYPE html>
<html>
<head>
    <title>Selamat Datang di Ujian Online</title>
    <link rel="stylesheet" type="text/css" href="assets/style.css">
</head>
<body>
<div class="container" style="max-width:500px;">
    <h2>Selamat Datang di Sistem Ujian Online</h2>
    <div style="display:flex; flex-direction:column; gap:18px; margin-top:32px;">
        <a href="auth/login.php" style="text-decoration:none;">
            <button type="button" style="width:100%; font-size:17px;">Login</button>
        </a>
        <a href="auth/register.php" style="text-decoration:none;">
            <button type="button" style="width:100%; font-size:17px;">Registrasi</button>
        </a>
    </div>
</div>
</body>
</html>
