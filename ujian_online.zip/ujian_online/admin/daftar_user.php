<?php
session_start();
include "../config/koneksi.php";
if ($_SESSION['role'] != "admin") {
    header("Location: ../auth/login.php");
    exit();
}
?>
<link rel="stylesheet" type="text/css" href="../assets/style.css">
<div class="container" style="max-width:700px;">
<h2>Daftar Siswa</h2>
<table border="1" style="width:100%; border-collapse:collapse; background:#fafdff;">
<tr style="background:#b2f7ef; color:#008080;">
    <th>No</th><th>Nama</th><th>NIS</th><th>Username</th>
</tr>
<?php
$no = 1;
$q = mysqli_query($conn, "SELECT * FROM users WHERE role='siswa'");
while ($d = mysqli_fetch_array($q)) {
    echo "<tr><td>$no</td><td>$d[nama]</td><td>$d[nis]</td><td>$d[username]</td></tr>";
    $no++;
}
?>
</table>
<a href="dashboard.php" style="display:inline-block; margin-top:18px;">
    <button type="button">Kembali</button>
</a>
</div>
