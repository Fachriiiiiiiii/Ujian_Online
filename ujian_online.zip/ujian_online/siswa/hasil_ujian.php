<?php
session_start();
include "../config/koneksi.php";
if ($_SESSION['role'] != "siswa") {
    header("Location: ../auth/login.php");
    exit();
}

$id_user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id FROM users WHERE username = '$_SESSION[username]'"))['id'];

if (!isset($_GET['ujian']) || !$_GET['ujian']) {
    $last = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id_ujian FROM nilai WHERE id_user='$id_user' ORDER BY id DESC LIMIT 1"));
    $id_ujian = $last ? $last['id_ujian'] : 0;
} else {
    $id_ujian = intval($_GET['ujian']);
}

$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM nilai WHERE id_user = '$id_user' AND id_ujian = '$id_ujian'"));
$ujian = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM ujian WHERE id='$id_ujian'"));
$jumlah_soal = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM soal WHERE id_ujian='$id_ujian'"));
$jumlah_benar = 0;
$jawaban_q = mysqli_query($conn, "SELECT * FROM jawaban_siswa WHERE id_user='$id_user' AND id_ujian='$id_ujian'");
while ($j = mysqli_fetch_assoc($jawaban_q)) {
    if ($j['benar_salah']) $jumlah_benar++;
}
$jumlah_salah = $jumlah_soal - $jumlah_benar;
?>
<link rel="stylesheet" type="text/css" href="../assets/style.css">
<div class="container" style="max-width:600px;">
    <h2>Hasil Ujian Anda</h2>
    <p><strong>Ujian:</strong> <?= htmlspecialchars($ujian['nama_ujian'] ?? '-') ?></p>
    <p><strong>Nilai:</strong> <?= $data['nilai_total'] ?? 'Belum Ujian' ?></p>
    <p><strong>Jumlah Soal:</strong> <?= $jumlah_soal ?></p>
    <p><strong>Benar:</strong> <?= $jumlah_benar ?> &nbsp; <strong>Salah:</strong> <?= $jumlah_salah ?></p>
    <a href="dashboard.php">
        <button type="button">Kembali ke Dashboard</button>
    </a>
</div>
    </a>
</div>
