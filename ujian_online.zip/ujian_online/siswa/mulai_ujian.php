<?php
session_start();
include "../config/koneksi.php";
if ($_SESSION['role'] != "siswa") {
    header("Location: ../auth/login.php");
    exit();
}

$id_user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id FROM users WHERE username = '$_SESSION[username]'"))['id'];

// Pilih ujian
if (!isset($_GET['ujian'])) {
    ?>
    <link rel="stylesheet" type="text/css" href="../assets/style.css">
    <div class="container" style="max-width:600px;">
    <h2>Pilih Ujian</h2>
    <form method="get">
        <div style="margin-bottom:24px;">
            <label for="ujian">Ujian</label>
            <select name="ujian" id="ujian" required>
                <option value="">Pilih Ujian</option>
                <?php
                $q = mysqli_query($conn, "SELECT * FROM ujian WHERE status='aktif'");
                while ($u = mysqli_fetch_assoc($q)) {
                    echo "<option value='$u[id]'>$u[nama_ujian]</option>";
                }
                ?>
            </select>
        </div>
        <button type="submit">Mulai</button>
    </form>
    </div>
    <?php
    exit();
}

$id_ujian = $_GET['ujian'];
$ujian = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM ujian WHERE id='$id_ujian'"));
$durasi = $ujian['durasi'];

// Ambil semua soal
$soal_q = mysqli_query($conn, "SELECT * FROM soal WHERE id_ujian='$id_ujian' ORDER BY id ASC");
$soal_arr = [];
while ($row = mysqli_fetch_assoc($soal_q)) {
    $soal_arr[] = $row;
}
$total_soal = count($soal_arr);

// Nomor soal sekarang
$no = isset($_GET['no']) ? intval($_GET['no']) : 1;
if ($no < 1) $no = 1;
if ($no > $total_soal) $no = $total_soal;
$soal = $soal_arr[$no-1] ?? null;

// Timer
if (!isset($_SESSION['waktu_mulai_'.$id_ujian])) {
    $_SESSION['waktu_mulai_'.$id_ujian] = time();
}
$waktu_mulai = $_SESSION['waktu_mulai_'.$id_ujian];
$waktu_selesai = $waktu_mulai + ($durasi * 60);
$sisa_detik = $waktu_selesai - time();
if ($sisa_detik <= 0) {
    echo "<script>alert('Waktu ujian habis!');window.location='hasil_ujian.php';</script>";
    exit();
}

// Session untuk jawaban & ragu-ragu
if (!isset($_SESSION['jawaban_'.$id_ujian])) {
    $_SESSION['jawaban_'.$id_ujian] = [];
}
if (!isset($_SESSION['ragu_'.$id_ujian])) {
    $_SESSION['ragu_'.$id_ujian] = [];
}

// Simpan jawaban
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['jawab'])) {
    $_SESSION['jawaban_'.$id_ujian][$soal['id']] = $_POST['jawaban'] ?? '';

    // Tombol Ragu-ragu
    if (isset($_POST['ragu'])) {
        if (!in_array($soal['id'], $_SESSION['ragu_'.$id_ujian])) {
            $_SESSION['ragu_'.$id_ujian][] = $soal['id']; // set ragu
        } else {
            // Hapus dari ragu
            $_SESSION['ragu_'.$id_ujian] = array_diff($_SESSION['ragu_'.$id_ujian], [$soal['id']]);
        }
    }

    // Navigasi
    if (isset($_POST['next'])) {
        header("Location: mulai_ujian.php?ujian=$id_ujian&no=".($no+1));
        exit();
    } elseif (isset($_POST['prev'])) {
        header("Location: mulai_ujian.php?ujian=$id_ujian&no=".($no-1));
        exit();
    } elseif (isset($_POST['selesai'])) {
        $benar = 0;
        foreach ($soal_arr as $s) {
            $id_soal = $s['id'];
            $jawab = $_SESSION['jawaban_'.$id_ujian][$id_soal] ?? '';
            $is_benar = ($jawab == $s['jawaban']) ? 1 : 0;
            $benar += $is_benar;
            mysqli_query($conn, "INSERT INTO jawaban_siswa (id_user, id_soal, id_ujian, jawaban, benar_salah) VALUES ('$id_user', '$id_soal', '$id_ujian', '$jawab', '$is_benar')");
        }
        $nilai = round(($benar / $total_soal) * 100);
        mysqli_query($conn, "INSERT INTO nilai (id_user, id_ujian, nilai_total) VALUES ('$id_user', '$id_ujian', '$nilai')");
        unset($_SESSION['jawaban_'.$id_ujian]);
        unset($_SESSION['ragu_'.$id_ujian]);
        unset($_SESSION['waktu_mulai_'.$id_ujian]);
        echo "<script>alert('Ujian selesai! Nilai Anda: $nilai'); window.location='hasil_ujian.php';</script>";
        exit();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="../assets/style.css">
    <style>
        .nav-soal { display: flex; flex-wrap: wrap; gap: 5px; margin-bottom: 20px; }
        .nav-soal a {
            display: inline-block;
            padding: 8px 12px;
            text-decoration: none;
            color: #000;
            border-radius: 4px;
            border: 1px solid #ccc;
            font-weight: bold;
        }
        .putih { background: #fff; }
        .hijau { background: #4CAF50; color: #fff; }
        .kuning { background: #FFC107; }
    </style>
    <script>
    var sisa = <?= $sisa_detik ?>;
    function updateTimer() {
        var m = Math.floor(sisa/60);
        var s = sisa%60;
        document.getElementById('timer').innerHTML = m+" menit "+s+" detik";
        if (sisa <= 0) {
            alert('Waktu ujian habis!');
            window.location='hasil_ujian.php';
        }
        sisa--;
        setTimeout(updateTimer, 1000);
    }
    window.onload = updateTimer;
    </script>
</head>
<body>
<div class="container" style="max-width:800px;">
<h2><?= htmlspecialchars($ujian['nama_ujian']) ?></h2>
<div style="margin-bottom:18px; color:#008080;">
    Sisa waktu: <span id="timer"></span>
</div>

<!-- Navigasi Soal -->
<div class="nav-soal">
<?php
foreach ($soal_arr as $index => $s) {
    $num = $index + 1;
    $status = 'putih';
    $id_soal = $s['id'];

    if (in_array($id_soal, $_SESSION['ragu_'.$id_ujian])) {
        $status = 'kuning';
    } elseif (!empty($_SESSION['jawaban_'.$id_ujian][$id_soal])) {
        $status = 'hijau';
    }

    echo "<a href='mulai_ujian.php?ujian=$id_ujian&no=$num' class='$status'>$num</a>";
}
?>
</div>

<?php if ($soal) { ?>
<form method="post">
    <div class="soal">
        <p><?= $no ?>. <?= htmlspecialchars($soal['pertanyaan']) ?></p>
        <label><input type="radio" name="jawaban" value="A" <?= (($_SESSION['jawaban_'.$id_ujian][$soal['id']] ?? '')=='A')?'checked':''; ?>> A. <?= htmlspecialchars($soal['opsi_a']) ?></label><br>
        <label><input type="radio" name="jawaban" value="B" <?= (($_SESSION['jawaban_'.$id_ujian][$soal['id']] ?? '')=='B')?'checked':''; ?>> B. <?= htmlspecialchars($soal['opsi_b']) ?></label><br>
        <label><input type="radio" name="jawaban" value="C" <?= (($_SESSION['jawaban_'.$id_ujian][$soal['id']] ?? '')=='C')?'checked':''; ?>> C. <?= htmlspecialchars($soal['opsi_c']) ?></label><br>
        <label><input type="radio" name="jawaban" value="D" <?= (($_SESSION['jawaban_'.$id_ujian][$soal['id']] ?? '')=='D')?'checked':''; ?>> D. <?= htmlspecialchars($soal['opsi_d']) ?></label><br>
    </div>
    <div style="margin-top:18px;">
        <?php if ($no > 1) { ?>
            <button type="submit" name="prev" value="1">Sebelumnya</button>
        <?php } ?>
        <?php if ($no < $total_soal) { ?>
            <button type="submit" name="next" value="1">Selanjutnya</button>
        <?php } else { ?>
            <button type="submit" name="selesai" value="1" onclick="return confirm('Selesai ujian?')">Selesai Ujian</button>
        <?php } ?>
        <button type="submit" name="ragu" value="1">Ragu-ragu</button>
        <input type="hidden" name="jawab" value="1">
    </div>
</form>
<?php } else { ?>
    <p>Tidak ada soal untuk ujian ini.</p>
<?php } ?>

<a href="dashboard.php" style="display:inline-block; margin-top:18px;">
    <button type="button">Kembali ke Dashboard</button>
</a>
</div>
</body>
</html>
